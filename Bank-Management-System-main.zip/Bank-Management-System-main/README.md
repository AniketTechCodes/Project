# Bank-Management-System
This Program is related To Bank Management which is based on Java Swing and it Contains ADMIN, STAFF, CUSTOMER panel.
(1) You need To open PhP myAdmin and run all the command inside the Bank_Management_System.txt
(2) open the project in APACHE NET BEANS and open the project
    - Right Click on Project and resolve the problems inside it
        -in Mysql Drive/connector error add library with that driver name and add mysql connector.jar file
        - for Layout Liabrary error add Layout jar file with Layout_Library name file
(3) Now Run the project.
